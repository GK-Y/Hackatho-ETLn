# test_harness.py
# Simple harness to POST all test files to the running ETL API
import requests, os, time
folder = r"/mnt/data/etl_test_files"
files = [f for f in os.listdir(folder) if os.path.isfile(os.path.join(folder,f)) and not f.endswith('.zip')]
url = "http://127.0.0.1:8000/upload"
for fname in files:
    path = os.path.join(folder, fname)
    print("Uploading:", fname)
    try:
        with open(path, 'rb') as fh:
            r = requests.post(url, files={'file': (fname, fh)}, data={'source_id':'test_source'})
        print("Status:", r.status_code)
        try:
            print("JSON:", r.json())
        except Exception as e:
            print("Response text:", r.text)
    except Exception as e:
        print("Error uploading", fname, e)
    time.sleep(0.5)

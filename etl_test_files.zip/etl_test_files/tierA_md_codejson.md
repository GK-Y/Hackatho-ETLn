# Product Info

Some description here.

```json
{ "id": "prod-md-1", "title": "MD Widget", "price": 12.5 }
```

And an HTML snippet inside a fenced code block:

```html
<div><p>Price: $12.50</p></div>
```

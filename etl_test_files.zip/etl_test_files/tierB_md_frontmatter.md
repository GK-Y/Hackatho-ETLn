---
title: "Widget A - 2025"
published: 2025-11-18
authors:
  - "Editorial Team"
tags:
  - "gadget"
  - "featured"
---

# Page content

This markdown contains frontmatter YAML and inline html <span>tags</span>.
